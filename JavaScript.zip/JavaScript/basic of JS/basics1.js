console.log("Hello World")

  let a=4
  console.log(a)
  console.log(typeof(a))

  let b = 234.6
  console.log(typeof(b))

  var c = "Rahul Shetty"
  console.log(typeof(c))


  let required = true
  console.log(typeof(required))
  //null and undefined
// let c = a+b ( it did not work //we cannot redeclare variable with let keyword but possible with var)
   c = a+b // reassigning is allowed with let 
   //var c=a+b )this is also allowed)
  console.log(c)
 
 console.log(!required)









//these are comments
/*
dsds
dss
dss
*/