//Print the multiplication table with 7

number= 6
for (let i=1; i<=10; i++ ) 
{
    product = number*i
    console.log(number+" x "+i+" = "+product)
}