//wrate an array and multiply each element with 2 using foreach method
let a = [2,5,6,8,6,3];
let c=[];
function arr(element, index, a)
{
    a[index]=a[index]*3;
}
a.forEach(arr)
console.log(a)

let x = null
console.log(x)

let y
console.log(typeof(x))

