function name(a , b)
{
    return a+b;
}
let sum = name(4,5)
console.log(sum)