// let scopes =[1 ,4 ,2 ,5 ,7 ,8 ]
// let findNo=scores.find((elemant)=>elemant%2==0)
// console.log(findNo)


//to get current date
var date = new Date();
var cMonth=date.getMonth();
console.log(cMonth+1)

//arrow finction
var arrow1 = (a,b) => a*b;
console.log(arrow1(4,4)) 

//create sub array in the array
array1 = [2,3,4,5,6,7,4,68,66]
subArr=array1.slice(3,6)
console.log(subArr)


//write a prohram with arry and find the pirticular element in the array
console.log(array1.includes(6))
console.log(array1.indexOf(6))

a = "fghsnauhulka"
console.log(a.carAt(3))