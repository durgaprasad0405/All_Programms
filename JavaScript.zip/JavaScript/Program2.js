// Calculate the sum of odd numbers greater than 10 and less than 30
oddNumber1 = 33
oddNumber2 = 13
sum = oddNumber1+oddNumber2
if (sum>10 && sum<30)
{
    console.log("The given odd "+sum+" number is in between 10 and 30.")
}
else
{
    console.log("The given odd "+sum+" number is not in between 10 and 30.")
}