package Pojos;

public class Data {


	public int year;
	public int price;
	public String cupModel;
	public String hardDiskSize;

	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCupModel() {
		return cupModel;
	}
	public void setCupModel(String cupModel) {
		this.cupModel = cupModel;
	}
	public String getHardDiskSize() {
		return hardDiskSize;
	}
	public void setHardDiskSize(String hardDiskSize) {
		this.hardDiskSize = hardDiskSize;
	}
	


}
